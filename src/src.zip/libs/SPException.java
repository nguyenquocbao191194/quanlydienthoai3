package libs;

public class SPException extends Exception {
    public void getMassage() {
        System.out.println("Sản phẩm không tồn tại !");
    }
}
